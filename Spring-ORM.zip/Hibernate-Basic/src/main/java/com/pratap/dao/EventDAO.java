package com.pratap.dao;

import com.pratap.model.Event;

public interface EventDAO {
	public void save(Event e);
}
